# Isolated Chutney REPLAY Comparison

The detection metric is Tor’s receiver-side invariant `n_chan already set. Bug/attack. Closing.` summed over every relay. Sender markers are retained only to confirm that the controlled injection branch ran and are not a detection metric.

| Mode | Seed | Organic receiver invariant | Sender marker (sanity only) |
|---|---:|---:|---:|
| benign | 42 | 0 | 0 |
| attack | 42 | 680 | 684 |
| benign | 137 | 0 | 0 |
| attack | 137 | 704 | 715 |
| benign | 2718 | 1 | 1 |
| attack | 2718 | 700 | 704 |

Attack organic counts: [680, 704, 700]. Benign organic counts: [0, 0, 1].

Verdict: inconclusive; do not claim detection. Inspect per-run logs and relay_counts.csv.
