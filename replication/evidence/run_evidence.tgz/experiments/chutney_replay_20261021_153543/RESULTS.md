# Isolated Chutney REPLAY Comparison

The detection metric is Tor’s receiver-side invariant `n_chan already set. Bug/attack. Closing.` summed over every relay. Sender markers are retained only to confirm that the controlled injection branch ran and are not a detection metric.

| Mode | Seed | Organic receiver invariant | Sender marker (sanity only) |
|---|---:|---:|---:|
| benign | 42 | 0 | 0 |
| attack | 42 | 0 | 0 |
| benign | 137 | 0 | 0 |
| attack | 137 | 0 | 0 |
| benign | 2718 | 0 | 0 |
| attack | 2718 | 0 | 0 |

Attack organic counts: [0, 0, 0]. Benign organic counts: [0, 0, 0].

Verdict: inconclusive; do not claim detection. Inspect per-run logs and relay_counts.csv.
